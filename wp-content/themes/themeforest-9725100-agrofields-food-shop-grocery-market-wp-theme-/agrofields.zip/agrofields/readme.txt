/**
 * @package 	WordPress
 * @subpackage 	Agrofields
 * @version 	1.1.1
 * 
 * Theme Information
 * Created by CMSMasters
 * 
*/


To update your theme please use the files list from the FILE LOGS below and substitute/add the listed files on your server with the same files in the Updates folder.

Important: after you have updated the theme, in your admin panel please proceed to
Theme Settings - Fonts and click "Save" in any tab,
then proceed to 
Theme Settings - Colors and click "Save" in any tab here.


-----------------------------------------------------------------------
			FILE LOGS
-----------------------------------------------------------------------


Version 1.1.1: files operations:

 Theme Files edited:

	agrofields\css\adaptive.css
	agrofields\css\retina.css
	agrofields\framework\postType\portfolio\post\gallery.php
	agrofields\framework\postType\portfolio\post\video.php
	agrofields\js\jqueryLibraries.min.js
	agrofields\tribe-events\default-template.php
	agrofields\header.php
	agrofields\style.css 
	agrofields\readme.txt

		
-------------------------------------------

Version 1.1.0: files operations:

 Theme Files edited:

	agrofields\css\cmsms-events-style.css
	agrofields\css\cmsms-events-style.less
	agrofields\framework\admin\settings\cmsms-theme-settings.php
	agrofields\framework\function\template-functions.php
	agrofields\framework\function\template-functions-post.php
	agrofields\framework\function\theme-colors-primary.php
	agrofields\framework\function\theme-colors-secondary.php
	agrofields\framework\function\theme-fonts.php
	agrofields\framework\function\theme-functions.php
	agrofields\js\jquery.script.js
	agrofields\js\jqueryLibraries.min.js
	agrofields\tribe-events\modules\bar.php
	agrofields\tribe-events\pro\map\single-event.php
	agrofields\tribe-events\pro\related-events.php
	agrofields\tribe-events\pro\single-organizer.php
	agrofields\tribe-events\pro\single-venue.php
	agrofields\tribe-events\single-event.php
	agrofields\header.php
	agrofields\style.css 
	agrofields\readme.txt

	agrofields\framework\admin\inc\plugins\cmsms-content-composer.zip - folder replaced
	
-------------------------------------------
Version 1.0.1: files operations:

 Theme Files edited:

	agrofields\framework\function\theme-functions.php
	agrofields\js\jquery.script.js
	agrofields\js\jqueryLibraries.min.js
	agrofields\style.css 
	agrofields\readme.txt

	
   
 ------------------------------------------
 
 Version 1.0: Release!
 
